export interface EmailData {
  customerName: string;
  customerEmail: string;
  orderId: string;
  trackingUrl: string;
  amount: string;
  items: string[];
  city: string;
  createdAt: string;
}

const STEPS = [
  { day: 0,  label: "Confirmación del pedido",      sublabel: "Pedido procesado" },
  { day: 1,  label: "Pedido en camino",             sublabel: "En tránsito" },
  { day: 2,  label: "Centro de distribución",       sublabel: "Hub logístico" },
  { day: 3,  label: "En reparto en tu ciudad",      sublabel: "Repartidor asignado" },
  { day: 5,  label: "Primer intento de entrega",    sublabel: "Intento fallido · Demora" },
  { day: 6,  label: "Localizando tu pedido",        sublabel: "Señal en recuperación" },
  { day: 7,  label: "Control aduanero",             sublabel: "En revisión" },
  { day: 8,  label: "Verificación de dirección",    sublabel: "Pendiente de confirmación" },
  { day: 9,  label: "Pedido relanzado",             sublabel: "Nueva ruta asignada" },
  { day: 10, label: "Entrega inminente",            sublabel: "Repartidor en camino" },
];
const OFFSETS = [0, 1, 2, 3, 5, 6, 7, 8, 9, 10];

function fmtDate(d: Date) {
  return d.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}
function fmtShort(d: Date) {
  return d.toLocaleDateString("es-ES", { day: "numeric", month: "short" }) + ", " +
    d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
}

function buildEmailTimeline(activeStepIndex: number, createdAt: string): string {
  const base = new Date(createdAt).getTime();
  /* Mirror Seguimiento logic: first 5 steps always shown; steps 6-10 only when reached */
  const visibleCount = Math.max(5, activeStepIndex + 1);
  let rows = "";
  STEPS.slice(0, visibleCount).forEach((step, i) => {
    const done   = i < activeStepIndex;
    const active = i === activeStepIndex;
    const stepDate = new Date(base + OFFSETS[i] * 86400000);
    const isLast = i === visibleCount - 1;

    // done = solid black ✓ | active = white circle with black border | pending = grey
    const dotStyle = done
      ? `width:24px;height:24px;border-radius:50%;background:#111111;color:#ffffff;font-family:Arial,sans-serif;font-size:9px;font-weight:700;text-align:center;line-height:24px;`
      : active
      ? `width:20px;height:20px;border-radius:50%;background:#ffffff;color:#111111;font-family:Arial,sans-serif;font-size:9px;font-weight:700;text-align:center;line-height:20px;border:2px solid #111111;`
      : `width:24px;height:24px;border-radius:50%;background:#e0e0e0;color:#aaaaaa;font-family:Arial,sans-serif;font-size:9px;font-weight:700;text-align:center;line-height:24px;`;
    const dotText  = done ? "&#10003;" : String(i + 1);
    const lineBg   = done ? "#111111" : "#e5e5e5";
    const labelW   = done || active ? "600" : "400";
    const labelColor = done || active ? "#111111" : "#bbbbbb";
    const dateColor  = done ? "#555555" : active ? "#111111" : "#cccccc";
    const statusText = done ? `Completado`
                     : active ? `<strong style="color:#111111;">&#9654; En curso</strong>`
                     : `Previsto: ${fmtDate(stepDate)}`;

    rows += `
    <tr>
      <td width="28" valign="top" style="padding-bottom:${isLast ? "0" : "0"};">
        <table role="presentation" cellspacing="0" cellpadding="0" style="width:28px;">
          <tr>
            <td align="center">
              <div style="${dotStyle}">${dotText}</div>
            </td>
          </tr>
          ${!isLast ? `<tr><td align="center" style="padding:1px 0;"><div style="width:1px;height:26px;background:${lineBg};margin:0 auto;"></div></td></tr>` : ""}
        </table>
      </td>
      <td style="padding:3px 0 ${isLast ? "0" : "24px"} 14px;">
        <p style="margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;font-weight:${labelW};color:${labelColor};text-transform:uppercase;letter-spacing:0.1em;">${step.label}</p>
        <p style="margin:3px 0 0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10px;color:${dateColor};">${statusText}</p>
      </td>
    </tr>`;
  });
  return `<table role="presentation" width="100%" cellspacing="0" cellpadding="0">${rows}</table>`;
}

function buildProductRows(items: string[]): string {
  return items.map(item => `
    <tr>
      <td style="padding:11px 0;border-bottom:1px solid #f0f0f0;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="6" valign="top" style="padding-top:4px;">
              <div style="width:4px;height:4px;background:#111;border-radius:50%;"></div>
            </td>
            <td style="padding-left:10px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:12px;color:#222222;line-height:1.4;">${item}</td>
          </tr>
        </table>
      </td>
    </tr>`).join("");
}

function shell(opts: {
  badgeLabel: string;
  headlineES: string;
  preheader: string;
  trackingUrl: string;
  orderId: string;
  ctaLabel: string;
  customerName: string;
  customerEmail: string;
  amount: string;
  items: string[];
  createdAt: string;
  activeStep: number;
  bodyExtra?: string;
}): string {
  const year = new Date().getFullYear();
  const firstName = opts.customerName.split(" ")[0];
  const orderDate = fmtDate(new Date(opts.createdAt));

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title>${opts.preheader}</title>
</head>
<body style="margin:0;padding:0;background:#efefef;-webkit-text-size-adjust:100%;">
<div style="display:none;font-size:1px;max-height:0;overflow:hidden;color:#efefef;">${opts.preheader}</div>

<table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="#efefef">
<tr><td align="center" style="padding:36px 12px 48px;">
  <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #e0e0e0;">

    <!-- ━━━ TOP BLACK HEADER ━━━ -->
    <tr>
      <td style="background:#000000;padding:0;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td style="padding:22px 40px 16px;text-align:center;">
              <span style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:21px;font-weight:800;color:#ffffff;letter-spacing:0.3em;">ZARA</span>
            </td>
          </tr>
          <tr>
            <td style="padding:0 40px 20px;text-align:center;border-bottom:1px solid #282828;">
              <span style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;font-weight:600;color:#999999;letter-spacing:0.25em;text-transform:uppercase;">${opts.badgeLabel}</span>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- ━━━ TRACKING CODE HERO ━━━ -->
    <tr>
      <td style="background:#111111;padding:28px 40px;text-align:center;border-bottom:3px solid #000;">
        <p style="margin:0 0 6px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#777777;text-transform:uppercase;letter-spacing:0.22em;">Código de seguimiento</p>
        <p style="margin:0;font-family:'Courier New',Courier,monospace;font-size:26px;font-weight:700;color:#ffffff;letter-spacing:0.18em;">${opts.orderId}</p>
        <p style="margin:8px 0 0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10px;color:#555555;">${orderDate}</p>
      </td>
    </tr>

    <!-- ━━━ CUSTOMER GREETING ━━━ -->
    <tr>
      <td style="padding:32px 40px 24px;border-bottom:1px solid #ebebeb;">
        <h1 style="margin:0 0 14px;font-family:'Times New Roman',Georgia,serif;font-size:26px;font-weight:400;color:#111111;line-height:1.2;">${opts.headlineES}</h1>
        <p style="margin:0 0 6px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:13px;color:#444444;line-height:1.7;">
          Hola <strong style="color:#111111;">${firstName}</strong>, te confirmamos que tu pedido ha sido recibido y está siendo gestionado.
        </p>
        ${opts.bodyExtra ? `<div style="margin-top:16px;">${opts.bodyExtra}</div>` : ""}
        <!-- Customer info pill -->
        <table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:20px;border:1px solid #e8e8e8;background:#fafafa;">
          <tr>
            <td style="padding:12px 20px;">
              <table role="presentation" cellspacing="0" cellpadding="0">
                <tr>
                  <td style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;padding-right:20px;">Cliente</td>
                  <td style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;color:#111111;font-weight:600;">${opts.customerName}</td>
                </tr>
                <tr>
                  <td style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;padding-right:20px;padding-top:4px;">Email</td>
                  <td style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;color:#555555;padding-top:4px;">${opts.customerEmail}</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- ━━━ PRODUCTS ━━━ -->
    ${opts.items.length > 0 ? `
    <tr>
      <td style="padding:28px 40px;border-bottom:1px solid #ebebeb;">
        <p style="margin:0 0 16px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#999999;text-transform:uppercase;letter-spacing:0.2em;">Artículos del pedido</p>
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
          ${buildProductRows(opts.items)}
          <tr>
            <td style="padding:16px 0 0;border-top:1px solid #e5e5e5;margin-top:4px;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;color:#777777;">Total pagado (IVA incl.)</td>
                  <td align="right" style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:17px;font-weight:700;color:#111111;">€ ${opts.amount}</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>` : ""}

    <!-- ━━━ TIMELINE ━━━ -->
    <tr>
      <td style="padding:28px 40px 32px;border-bottom:1px solid #ebebeb;">
        <p style="margin:0 0 20px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#999999;text-transform:uppercase;letter-spacing:0.2em;">Estado de tu envío</p>
        ${buildEmailTimeline(opts.activeStep, opts.createdAt)}
      </td>
    </tr>

    <!-- ━━━ CTA ━━━ -->
    <tr>
      <td style="padding:36px 40px;text-align:center;border-bottom:1px solid #ebebeb;">
        <a href="${opts.trackingUrl}" target="_blank" style="display:inline-block;background-color:#111111;color:#ffffff;text-decoration:none;font-family:Arial,Helvetica,sans-serif;font-size:14px;font-weight:bold;padding:16px 40px;border:2px solid #111111;cursor:pointer;">${opts.ctaLabel}</a>
        <br><br>
        <span style="font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#aaaaaa;">O accede directamente:</span><br>
        <a href="${opts.trackingUrl}" target="_blank" style="font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#555555;text-decoration:underline;word-break:break-all;">${opts.trackingUrl}</a>
      </td>
    </tr>

    <!-- ━━━ FOOTER ━━━ -->
    <tr>
      <td style="padding:28px 40px;text-align:center;background:#f9f9f9;">
        <p style="margin:0 0 8px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#aaaaaa;letter-spacing:0.2em;text-transform:uppercase;">ZARA España · Atención al Cliente</p>
        <p style="margin:0 0 8px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10px;color:#bbbbbb;line-height:1.6;">Devoluciones gratuitas en 30 días · Envío estándar gratuito en pedidos +30€</p>
        <p style="margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#cccccc;">© ${year} ZARA España · Todos los derechos reservados</p>
      </td>
    </tr>

  </table>
</td></tr>
</table>
</body>
</html>`;
}

export function emailDay0(data: EmailData): { subject: string; html: string } {
  return {
    subject: `✓ Pedido ${data.orderId} confirmado — ZARA España`,
    html: shell({
      badgeLabel: "Confirmación del pedido",
      headlineES: `Tu pedido está confirmado`,
      preheader: `Pedido ${data.orderId} confirmado. Gracias por tu compra en ZARA España.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Seguir mi pedido en tiempo real",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 0,
    }),
  };
}

export function emailDay1(data: EmailData): { subject: string; html: string } {
  return {
    subject: `📦 Tu pedido ${data.orderId} está en camino — ZARA España`,
    html: shell({
      badgeLabel: "Pedido en camino",
      headlineES: `Tu pedido está en tránsito`,
      preheader: `Tu pedido ${data.orderId} ha salido de nuestros almacenes y está en camino a ${data.city}.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Ver estado del envío",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 1,
      bodyExtra: `<table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Entrega estimada</p>
          <p style="margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">En los próximos 2–3 días hábiles · ${data.city}</p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDay2(data: EmailData): { subject: string; html: string } {
  return {
    subject: `🏭 Pedido ${data.orderId} llegó al centro de distribución`,
    html: shell({
      badgeLabel: "En centro de distribución",
      headlineES: `Tu pedido está muy cerca`,
      preheader: `Tu pedido ${data.orderId} ha llegado al centro de distribución. Reparto mañana.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Ver estado del envío",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 2,
      bodyExtra: `<table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Próximo paso</p>
          <p style="margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">Mañana comenzará el reparto en tu zona · ${data.city}</p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDay3(data: EmailData): { subject: string; html: string } {
  return {
    subject: `🚚 Tu pedido ${data.orderId} está en reparto HOY`,
    html: shell({
      badgeLabel: "En reparto hoy",
      headlineES: `Tu pedido llega hoy`,
      preheader: `El repartidor está en camino con tu pedido ${data.orderId}. ¡Prepárate para recibirlo!`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Seguir el reparto en vivo",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 3,
      bodyExtra: `<table role="presentation" cellspacing="0" cellpadding="0" style="background:#111111;width:100%;">
        <tr><td style="padding:16px 24px;text-align:center;">
          <p style="margin:0 0 6px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.2em;">Estado actual</p>
          <p style="margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:15px;font-weight:700;color:#ffffff;letter-spacing:0.08em;">EN REPARTO · ${data.city.toUpperCase()}</p>
        </td></tr>
      </table>
      <p style="margin:14px 0 0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;color:#888888;line-height:1.6;text-align:center;">Si no puedes recibir el paquete, el transportista dejará un aviso para concertar una nueva entrega.</p>`,
    }),
  };
}

export function emailDay5(data: EmailData): { subject: string; html: string } {

  return {
    subject: `⚠️ Aviso importante sobre tu pedido ${data.orderId}`,
    html: shell({
      badgeLabel: "Aviso de demora",
      headlineES: `Actualización de tu pedido`,
      preheader: `Tu pedido ${data.orderId} presenta una pequeña demora. Te pedimos disculpas.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Ver estado actual del pedido",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 4,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#fff8f5;border:1px solid #f0d0c0;width:100%;margin-bottom:16px;">
        <tr><td style="padding:16px 20px;">
          <p style="margin:0 0 6px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10px;color:#c0533a;text-transform:uppercase;letter-spacing:0.15em;font-weight:700;">⚠ Aviso de demora · ${data.city}</p>
          <p style="margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:12px;color:#444444;line-height:1.6;">Tu pedido <strong>${data.orderId}</strong> está experimentando un pequeño retraso. Prevemos entrega en las próximas 24–48 horas. Disculpa los inconvenientes.</p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Como disculpa</p>
          <p style="margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">10% descuento en tu próxima compra — Código: <span style="font-family:'Courier New',monospace;letter-spacing:0.1em;">ZARA10</span></p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDay6(data: EmailData): { subject: string; html: string } {
  return {
    subject: `🔍 Estamos localizando tu pedido ${data.orderId} — ZARA España`,
    html: shell({
      badgeLabel: "Localización en curso",
      headlineES: `Estamos buscando tu pedido`,
      preheader: `Hemos perdido temporalmente la señal de tu pedido ${data.orderId}. Nuestro equipo está trabajando en ello.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Ver estado de localización",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 5,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f8ff;border:1px solid #c8d8f0;width:100%;margin-bottom:16px;">
        <tr><td style="padding:16px 20px;">
          <p style="margin:0 0 6px;font-family:Arial,sans-serif;font-size:10px;color:#3a5fa0;text-transform:uppercase;letter-spacing:0.15em;font-weight:700;">🔍 Señal de rastreo interrumpida</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;color:#444444;line-height:1.6;">Nuestro sistema de rastreo ha perdido temporalmente la señal de tu paquete. Esto ocurre durante traslados entre centros logísticos. Estamos trabajando para recuperar la localización en las próximas <strong>2–4 horas</strong>.</p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">No es necesaria ninguna acción</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">Tu paquete está en tránsito y será localizado muy pronto. Te avisaremos en cuanto tengamos novedades.</p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDay7(data: EmailData): { subject: string; html: string } {
  return {
    subject: `📦 Tu paquete está en control aduanero — Pedido ${data.orderId}`,
    html: shell({
      badgeLabel: "Control aduanero",
      headlineES: `Tu pedido está en revisión aduanera`,
      preheader: `Tu pedido ${data.orderId} ha sido detectado en control aduanero. Esperamos resolución en 24–48 horas.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Consultar estado aduanero",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 6,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;margin-bottom:16px;">
        <tr><td style="padding:16px 20px;">
          <p style="margin:0 0 4px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Referencia aduanera</p>
          <p style="margin:0;font-family:'Courier New',monospace;font-size:14px;font-weight:700;color:#111111;letter-spacing:0.12em;">ES-ADU-${data.orderId}-7</p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#fffbf0;border:1px solid #e8d88a;width:100%;">
        <tr><td style="padding:16px 20px;">
          <p style="margin:0 0 6px;font-family:Arial,sans-serif;font-size:10px;color:#8a6d00;text-transform:uppercase;letter-spacing:0.15em;font-weight:700;">📋 Proceso habitual — Sin coste adicional</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;color:#444444;line-height:1.6;">El control aduanero es un procedimiento estándar de verificación. Tu pedido <strong>no está retenido</strong> ni requiere ningún pago adicional. Estimamos resolución en <strong>24–48 horas</strong>.</p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDay8(data: EmailData): { subject: string; html: string } {
  return {
    subject: `⚠️ Confirma tu dirección para recibir tu pedido ${data.orderId}`,
    html: shell({
      badgeLabel: "Verificación de dirección",
      headlineES: `Necesitamos confirmar tu dirección`,
      preheader: `Acción requerida: confirma tu dirección de entrega para el pedido ${data.orderId} antes de 24 horas.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Confirmar mi dirección ahora",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 7,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#fff8f5;border:1px solid #f0d0c0;width:100%;margin-bottom:16px;">
        <tr><td style="padding:16px 20px;">
          <p style="margin:0 0 6px;font-family:Arial,sans-serif;font-size:10px;color:#c0533a;text-transform:uppercase;letter-spacing:0.15em;font-weight:700;">⚠ Acción requerida · Plazo 24 horas</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;color:#444444;line-height:1.6;">Nuestro transportista no ha podido verificar la dirección de entrega. Si no confirmamos los datos en <strong>24 horas</strong>, el pedido podría ser devuelto al almacén.</p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Cómo confirmar</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">Pulsa el botón de abajo y verifica que la dirección registrada es correcta. Solo tarda 30 segundos.</p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDay9(data: EmailData): { subject: string; html: string } {
  return {
    subject: `✅ Tu pedido ${data.orderId} ha sido relanzado — Nueva fecha de entrega`,
    html: shell({
      badgeLabel: "Pedido relanzado",
      headlineES: `Tu pedido está de nuevo en camino`,
      preheader: `¡Buenas noticias! Tu pedido ${data.orderId} ha sido relanzado con una nueva ruta de entrega hacia ${data.city}.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Seguir el nuevo envío",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 8,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f0fff4;border:1px solid #9ed4b0;width:100%;margin-bottom:16px;">
        <tr><td style="padding:16px 20px;">
          <p style="margin:0 0 6px;font-family:Arial,sans-serif;font-size:10px;color:#1a6b35;text-transform:uppercase;letter-spacing:0.15em;font-weight:700;">✅ Dirección verificada — Envío activo</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;color:#444444;line-height:1.6;">Tu dirección ha sido confirmada y tu pedido ha sido asignado a un nuevo repartidor. Estimamos la entrega en <strong>1–2 días hábiles</strong> en ${data.city}.</p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Compensación por la espera</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">15% de descuento en tu próxima compra — Código: <span style="font-family:'Courier New',monospace;letter-spacing:0.1em;">ZARA15</span></p>
        </td></tr>
      </table>`,
    }),
  };
}

/* ── Retry cycle (days 11–20): alternates between these two functions ── */

export function emailDayNoRecibido(data: EmailData): { subject: string; html: string } {
  const manana = new Date(Date.now() + 86400000);
  const mananaStr = manana.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" });
  return {
    subject: `⚠️ Tu pedido ${data.orderId} no pudo ser entregado hoy`,
    html: shell({
      badgeLabel: "Intento de entrega fallido",
      headlineES: `Lo intentaremos de nuevo mañana`,
      preheader: `Tu pedido ${data.orderId} no pudo ser entregado hoy. Nuestro repartidor lo reintentará mañana.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Ver estado de tu pedido",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 9,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#fff8f5;border:1px solid #f0d0c0;width:100%;margin-bottom:16px;">
        <tr><td style="padding:16px 20px;">
          <p style="margin:0 0 6px;font-family:Arial,sans-serif;font-size:10px;color:#c0533a;text-transform:uppercase;letter-spacing:0.15em;font-weight:700;">⚠ Entrega no completada · ${data.city}</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;color:#444444;line-height:1.6;">Nuestro repartidor intentó entregar tu pedido <strong>${data.orderId}</strong> hoy pero no fue posible completar la entrega. Lo reintentará <strong>mañana, ${mananaStr}</strong> en la misma dirección.</p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">¿No estarás en casa mañana?</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">Accede a tu seguimiento y deja instrucciones para el repartidor — también puedes solicitar entrega en punto de recogida.</p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDayEnRuta(data: EmailData): { subject: string; html: string } {
  return {
    subject: `🚚 Tu pedido ${data.orderId} está de nuevo en ruta de entrega`,
    html: shell({
      badgeLabel: "En ruta de entrega",
      headlineES: `Tu pedido sale hoy hacia tu dirección`,
      preheader: `¡Tu pedido ${data.orderId} está de nuevo en ruta! El repartidor saldrá hacia tu dirección esta mañana.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Seguir la entrega en tiempo real",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 9,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#111111;width:100%;margin-bottom:16px;">
        <tr><td style="padding:20px 24px;text-align:center;">
          <p style="margin:0 0 6px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.2em;">Estado actual</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:17px;font-weight:700;color:#ffffff;letter-spacing:0.06em;">🚚 EN RUTA HACIA TU DIRECCIÓN</p>
          <p style="margin:8px 0 0;font-family:Arial,sans-serif;font-size:11px;color:#666666;">Ventana de entrega estimada: <strong style="color:#aaaaaa;">10:00 – 20:00 h · ${data.city}</strong></p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Asegúrate de estar disponible</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">El repartidor realizará un solo intento hoy. Si no estás, dejará aviso para el siguiente día.</p>
        </td></tr>
      </table>`,
    }),
  };
}

export function emailDay10(data: EmailData): { subject: string; html: string } {
  return {
    subject: `🚚 Tu repartidor está a 2 paradas de ti — Pedido ${data.orderId}`,
    html: shell({
      badgeLabel: "Entrega inminente",
      headlineES: `Tu pedido llega hoy`,
      preheader: `¡Tu pedido ${data.orderId} está a minutos de tu puerta! El repartidor está en camino ahora mismo.`,
      trackingUrl: data.trackingUrl,
      orderId: data.orderId,
      ctaLabel: "Ver estado de entrega",
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      amount: data.amount,
      items: data.items,
      createdAt: data.createdAt,
      activeStep: 9,
      bodyExtra: `
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#111111;width:100%;margin-bottom:16px;">
        <tr><td style="padding:20px 24px;text-align:center;">
          <p style="margin:0 0 6px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.2em;">Estado en tiempo real</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:17px;font-weight:700;color:#ffffff;letter-spacing:0.06em;">🚚 A 2 PARADAS DE TU DIRECCIÓN</p>
          <p style="margin:8px 0 0;font-family:Arial,sans-serif;font-size:11px;color:#666666;">Ventana de entrega: <strong style="color:#aaaaaa;">14:00 – 18:00 h · ${data.city}</strong></p>
        </td></tr>
      </table>
      <table role="presentation" cellspacing="0" cellpadding="0" style="background:#f5f5f5;border-left:3px solid #111;width:100%;">
        <tr><td style="padding:14px 18px;">
          <p style="margin:0 0 4px;font-family:Arial,sans-serif;font-size:9px;color:#888888;text-transform:uppercase;letter-spacing:0.15em;">Si no estás en casa</p>
          <p style="margin:0;font-family:Arial,sans-serif;font-size:13px;font-weight:600;color:#111111;">El repartidor dejará un aviso y reintentará la entrega al día siguiente sin coste adicional.</p>
        </td></tr>
      </table>`,
    }),
  };
}
