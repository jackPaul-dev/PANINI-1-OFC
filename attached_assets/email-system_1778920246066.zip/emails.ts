import { Router } from "express";
import { Resend } from "resend";
import { getStripeClient } from "../lib/stripeClient.js";
import {
  createOrder,
  getOrder,
  getOrderByPaymentIntent,
  getOrderByEmail,
  listOrders,
  addEmailRecord,
  upsertOrder,
  type Order,
} from "../lib/orderStore.js";
import {
  emailDay0,
  emailDay1,
  emailDay2,
  emailDay3,
  emailDay5,
  emailDay6,
  emailDay7,
  emailDay8,
  emailDay9,
  emailDay10,
  emailDayNoRecibido,
  emailDayEnRuta,
} from "../lib/emailTemplates.js";
import { sendTikTokPurchase } from "../lib/tiktokEvents.js";

const router = Router();

function getResend(): Resend {
  const key = process.env.RESEND_API_KEY;
  if (!key) throw new Error("RESEND_API_KEY not configured");
  return new Resend(key);
}

const FROM = process.env.EMAIL_FROM || "ZARA España <noreply@zraoficial-ofc.site>";

const TRACKING_BASE =
  (process.env.TRACKING_BASE_URL || "https://zraoficial.site").replace(/\/$/, "");

const EMAIL_DAYS = [
  { day: 0,  offsetHours: 0 },
  { day: 1,  offsetHours: 24 },
  { day: 2,  offsetHours: 48 },
  { day: 3,  offsetHours: 72 },
  { day: 5,  offsetHours: 120 },
  { day: 6,  offsetHours: 144 },
  { day: 7,  offsetHours: 168 },
  { day: 8,  offsetHours: 192 },
  { day: 9,  offsetHours: 216 },
  { day: 10, offsetHours: 240 },
  /* Retry cycle — alternates NoRecibido / EnRuta */
  { day: 11, offsetHours: 264 },
  { day: 12, offsetHours: 288 },
  { day: 13, offsetHours: 312 },
  { day: 14, offsetHours: 336 },
  { day: 15, offsetHours: 360 },
  { day: 16, offsetHours: 384 },
  { day: 17, offsetHours: 408 },
  { day: 18, offsetHours: 432 },
  { day: 19, offsetHours: 456 },
  { day: 20, offsetHours: 480 },
];

async function sendEmailSequence(order: Order) {
  const resend = getResend();
  const trackingUrl = `${TRACKING_BASE}/seguimiento?orderId=${order.orderId}`;
  const data = {
    customerName: order.customerName,
    customerEmail: order.customerEmail,
    orderId: order.orderId,
    trackingUrl,
    amount: order.amount.toFixed(2),
    items: order.items,
    city: order.city,
    createdAt: order.createdAt,
  };

  const builders = [
    emailDay0, emailDay1, emailDay2, emailDay3, emailDay5,
    emailDay6, emailDay7, emailDay8, emailDay9, emailDay10,
    /* days 11–20: alternate NoRecibido / EnRuta */
    emailDayNoRecibido, emailDayEnRuta,
    emailDayNoRecibido, emailDayEnRuta,
    emailDayNoRecibido, emailDayEnRuta,
    emailDayNoRecibido, emailDayEnRuta,
    emailDayNoRecibido, emailDayEnRuta,
  ];

  for (let i = 0; i < EMAIL_DAYS.length; i++) {
    const { day, offsetHours } = EMAIL_DAYS[i];
    const { subject, html } = builders[i](data);

    const scheduledAt =
      offsetHours > 0
        ? new Date(Date.now() + offsetHours * 3600 * 1000).toISOString()
        : undefined;

    let resendId: string | null = null;
    let status: "sent" | "scheduled" | "failed" = "sent";

    try {
      const payload: Record<string, unknown> = {
        from: FROM,
        to: order.customerEmail,
        subject,
        html,
      };
      if (scheduledAt) payload.scheduledAt = scheduledAt;

      const result = await resend.emails.send(payload as unknown as Parameters<Resend["emails"]["send"]>[0]);
      resendId = result.data?.id ?? null;
      status = scheduledAt ? "scheduled" : "sent";
    } catch (err: any) {
      console.error(`Failed to send day ${day} email:`, err.message);
      status = "failed";
    }

    addEmailRecord(order.orderId, {
      day,
      subject,
      resendId,
      status,
      scheduledAt: scheduledAt ?? null,
      sentAt: new Date().toISOString(),
    });
  }
}

/* POST /api/emails/trigger — called by frontend after successful payment */
router.post("/emails/trigger", async (req, res) => {
  try {
    const {
      paymentIntentId,
      customerEmail,
      customerName,
      address,
      city,
      postalCode,
      province,
      country,
      amount,
      items,
    } = req.body as {
      paymentIntentId: string;
      customerEmail: string;
      customerName: string;
      address: string;
      city: string;
      postalCode: string;
      province: string;
      country: string;
      amount: number;
      items: string[];
    };

    if (!customerEmail || !paymentIntentId) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    /* Deduplication: if webhook already created an order for this PI, return it */
    const existing = getOrderByPaymentIntent(paymentIntentId);
    if (existing) {
      res.json({ orderId: existing.orderId, message: "Already triggered by webhook" });
      return;
    }

    const order = createOrder({
      paymentIntentId,
      customerEmail,
      customerName,
      address,
      city,
      postalCode,
      province,
      country,
      amount,
      items,
    });

    sendEmailSequence(order).catch(console.error);

    // TikTok Conversions API — fires here because Stripe webhook isn't used in production
    sendTikTokPurchase({
      eventId: paymentIntentId,
      eventTime: Math.floor(Date.now() / 1000),
      value: amount,
      currency: "EUR",
      orderId: order.orderId,
      customerEmail,
      phone: undefined,
      city,
      postalCode,
      country,
      numItems: items.length || undefined,
      ip: undefined,
      userAgent: undefined,
    }).catch(console.error);

    res.json({ orderId: order.orderId, message: "Email sequence triggered" });
  } catch (err: any) {
    console.error("Email trigger error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/* GET /api/emails/orders — dashboard list */
router.get("/emails/orders", (_req, res) => {
  res.json(listOrders());
});

/* GET /api/orders/:orderId — tracking page */
router.get("/orders/:orderId", (req, res) => {
  const order = getOrder(req.params.orderId);
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  res.json({
    orderId: order.orderId,
    customerName: order.customerName,
    city: order.city,
    createdAt: order.createdAt,
    amount: order.amount,
    items: order.items,
    emails: order.emails,
  });
});

/* POST /api/emails/test — send all 5 test emails immediately (no scheduling) */
router.post("/emails/test", async (req, res) => {
  try {
    const { email } = req.body as { email: string };
    if (!email) { res.status(400).json({ error: "Missing email" }); return; }

    const resend = getResend();
    const now = new Date().toISOString();
    /* trackingCreatedAt: old date so the demo tracking page shows all 10 steps */
    const trackingCreatedAt = new Date(Date.now() - 11 * 86400000).toISOString();
    /* emailCreatedAt: today so email body dates look current and correct */
    const emailCreatedAt = new Date().toISOString();
    const testOrderId = "SHA-DEMO7X";
    const testItems = [
      "1x BLAZER AJUSTADA ASIMÉTRICA CON HOMBRERAS — Beige — Talla M",
      "2x PANTALÓN CULOTTE TELA — Negro — Talla S",
      "1x VESTIDO MIDI SATINADO ASIMÉTRICO — Rosa palo — Talla S",
    ];

    /* Save / refresh test order so the tracking page works */
    upsertOrder({
      orderId: testOrderId,
      paymentIntentId: "pi_test",
      customerEmail: email,
      customerName: "María García López",
      address: "Calle Gran Vía 28",
      city: "Madrid",
      postalCode: "28013",
      province: "Madrid",
      country: "ES",
      amount: 124.90,
      items: testItems,
      createdAt: trackingCreatedAt,
      emails: [],
    });

    const testData = {
      customerName: "María García López",
      customerEmail: email,
      orderId: testOrderId,
      trackingUrl: `${TRACKING_BASE}/seguimiento?orderId=${testOrderId}`,
      amount: "124.90",
      items: testItems,
      city: "Madrid",
      createdAt: emailCreatedAt,
    };

    const builders = [
      { fn: emailDay0,  label: "Día 0 — Confirmación" },
      { fn: emailDay1,  label: "Día 1 — En camino" },
      { fn: emailDay2,  label: "Día 2 — Centro distribución" },
      { fn: emailDay3,  label: "Día 3 — En reparto hoy" },
      { fn: emailDay5,  label: "Día 5 — Primer intento" },
      { fn: emailDay6,  label: "Día 6 — Localizando pedido" },
      { fn: emailDay7,  label: "Día 7 — Control aduanero" },
      { fn: emailDay8,  label: "Día 8 — Verificación dirección" },
      { fn: emailDay9,         label: "Día 9 — Pedido relanzado" },
      { fn: emailDay10,        label: "Día 10 — Entrega inminente" },
      { fn: emailDayNoRecibido, label: "Día 11 — No entregado hoy" },
      { fn: emailDayEnRuta,    label: "Día 12 — En ruta de nuevo" },
      { fn: emailDayNoRecibido, label: "Día 13 — No entregado hoy" },
      { fn: emailDayEnRuta,    label: "Día 14 — En ruta de nuevo" },
      { fn: emailDayNoRecibido, label: "Día 15 — No entregado hoy" },
      { fn: emailDayEnRuta,    label: "Día 16 — En ruta de nuevo" },
      { fn: emailDayNoRecibido, label: "Día 17 — No entregado hoy" },
      { fn: emailDayEnRuta,    label: "Día 18 — En ruta de nuevo" },
      { fn: emailDayNoRecibido, label: "Día 19 — No entregado hoy" },
      { fn: emailDayEnRuta,    label: "Día 20 — En ruta de nuevo" },
    ];

    const results: { day: string; id: string | null; status: string }[] = [];

    for (const { fn, label } of builders) {
      const { subject, html } = fn(testData);
      try {
        const result = await resend.emails.send({ from: FROM, to: email, subject, html });
        results.push({ day: label, id: result.data?.id ?? null, status: "sent" });
      } catch (err: any) {
        results.push({ day: label, id: null, status: `failed: ${err.message}` });
      }
      /* small gap so inbox shows them in order */
      await new Promise((r) => setTimeout(r, 300));
    }

    res.json({ ok: true, sent: results.length, results });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/* Helper: resolve order data from local store or Stripe — without persisting */
async function resolveOrderData(email: string): Promise<{
  orderId: string | null;
  customerName: string;
  customerEmail: string;
  city: string;
  amount: string;
  items: string[];
  createdAt: string;
  trackingUrl: string;
} | null> {
  const local = getOrderByEmail(email);
  if (local) {
    return {
      orderId: local.orderId,
      customerName: local.customerName,
      customerEmail: local.customerEmail,
      city: local.city,
      amount: local.amount.toFixed(2),
      items: local.items,
      createdAt: local.createdAt,
      trackingUrl: `${TRACKING_BASE}/seguimiento?orderId=${local.orderId}`,
    };
  }

  /* ── Stripe fallback ────────────────────────────────────────────── */
  const stripe = getStripeClient();
  const norm = email.toLowerCase().trim();
  const safe = email.replace(/'/g, "\\'");

  /* Helper: build order-data from a PaymentIntent + optional charge */
  type StripeCharge = import("stripe").Stripe.Charge;
  async function fromPI(
    pi: import("stripe").Stripe.PaymentIntent,
    charge?: StripeCharge | null,
  ) {
    /* Fetch charge if not provided */
    if (!charge && typeof pi.latest_charge === "string") {
      try {
        charge = await stripe.charges.retrieve(pi.latest_charge) as StripeCharge;
      } catch { /* ignore */ }
    }

    const m   = pi.metadata ?? {};
    const bd  = (charge as any)?.billing_details ?? {};

    /* ── Customer info — prefer billing_details over metadata ── */
    const customerName  = bd.name  || m.customer_name  || "Cliente";
    const customerEmail = bd.email || m.customer_email || email;
    const city          = bd.address?.city || m.city   || "";
    const address       = bd.address?.line1 || m.address || "";

    /* ── Items — only real data, never placeholders ── */
    let items: string[] = [];
    try {
      items = JSON.parse(m.items_detail ?? m.items ?? "[]");
    } catch { items = []; }

    const byPi  = getOrderByPaymentIntent(pi.id);
    const orderId = byPi?.orderId ?? null;

    return {
      orderId,
      customerName,
      customerEmail,
      city,
      amount: (pi.amount / 100).toFixed(2),
      items,
      createdAt: byPi?.createdAt ?? new Date(pi.created * 1000).toISOString(),
      trackingUrl: orderId
        ? `${TRACKING_BASE}/seguimiento?orderId=${orderId}`
        : `${TRACKING_BASE}/seguimiento`,
    };
  }

  /* 1 — Search by metadata customer_email (recent purchases) */
  try {
    const search = await stripe.paymentIntents.search({
      query: `metadata["customer_email"]:"${safe}" AND status:"succeeded"`,
      limit: 1,
      expand: ["data.latest_charge"],
    });
    const pi = search.data[0];
    if (pi) return fromPI(pi, (pi as any).latest_charge);
  } catch { /* search API not available */ }

  /* 2 — Search charges by billing email (catches older purchases) */
  try {
    const cSearch = await (stripe.charges as any).search({
      query: `email:"${safe}" AND status:"succeeded"`,
      limit: 1,
    });
    const charge: StripeCharge = cSearch.data?.[0];
    if (charge && charge.payment_intent) {
      const pi = await stripe.paymentIntents.retrieve(
        charge.payment_intent as string
      );
      if (pi.status === "succeeded") return fromPI(pi, charge);
    }
  } catch { /* ignore */ }

  /* 3 — List fallback: scan recent PIs and charges */
  try {
    const [piList, chargeList] = await Promise.all([
      stripe.paymentIntents.list({ limit: 100, expand: ["data.latest_charge"] }),
      stripe.charges.list({ limit: 100 }),
    ]);

    const pi = piList.data.find(
      (p) =>
        p.status === "succeeded" &&
        p.metadata?.customer_email?.toLowerCase() === norm,
    );
    if (pi) return fromPI(pi, (pi as any).latest_charge);

    const charge = chargeList.data.find(
      (c) =>
        c.status === "succeeded" &&
        (c.billing_details?.email?.toLowerCase() === norm ||
          c.metadata?.customer_email?.toLowerCase() === norm),
    );
    if (charge && charge.payment_intent) {
      const pi2 = await stripe.paymentIntents.retrieve(
        charge.payment_intent as string
      );
      if (pi2.status === "succeeded") return fromPI(pi2, charge);
    }
  } catch { /* ignore */ }

  return null;
}

const DAY_BUILDERS = [
  { day: 0,  label: "Día 0 — Confirmación",           fn: emailDay0 },
  { day: 1,  label: "Día 1 — En camino",              fn: emailDay1 },
  { day: 2,  label: "Día 2 — Centro distribución",    fn: emailDay2 },
  { day: 3,  label: "Día 3 — En reparto hoy",         fn: emailDay3 },
  { day: 5,  label: "Día 5 — Primer intento",         fn: emailDay5 },
  { day: 6,  label: "Día 6 — Localizando pedido",     fn: emailDay6 },
  { day: 7,  label: "Día 7 — Control aduanero",       fn: emailDay7 },
  { day: 8,  label: "Día 8 — Verificación dirección", fn: emailDay8 },
  { day: 9,  label: "Día 9 — Pedido relanzado",        fn: emailDay9 },
  { day: 10, label: "Día 10 — Entrega inminente",      fn: emailDay10 },
  { day: 11, label: "Día 11 — No entregado hoy",       fn: emailDayNoRecibido },
  { day: 12, label: "Día 12 — En ruta de nuevo",       fn: emailDayEnRuta },
  { day: 13, label: "Día 13 — No entregado hoy",       fn: emailDayNoRecibido },
  { day: 14, label: "Día 14 — En ruta de nuevo",       fn: emailDayEnRuta },
  { day: 15, label: "Día 15 — No entregado hoy",       fn: emailDayNoRecibido },
  { day: 16, label: "Día 16 — En ruta de nuevo",       fn: emailDayEnRuta },
  { day: 17, label: "Día 17 — No entregado hoy",       fn: emailDayNoRecibido },
  { day: 18, label: "Día 18 — En ruta de nuevo",       fn: emailDayEnRuta },
  { day: 19, label: "Día 19 — No entregado hoy",       fn: emailDayNoRecibido },
  { day: 20, label: "Día 20 — En ruta de novo",        fn: emailDayEnRuta },
];

/* POST /api/emails/preview — returns rendered HTML for a given email day.
   Never returns 404 — falls back to placeholder data so the template is
   always visible even when the order isn't in the local store or Stripe. */
router.post("/emails/preview", async (req, res) => {
  try {
    const { email, day = 0 } = req.body as { email?: string; day?: number };
    if (!email) { res.status(400).json({ error: "Missing email" }); return; }

    let data = await resolveOrderData(email);
    let isPlaceholder = false;

    if (!data) {
      /* Fallback: render with placeholder data so preview always works */
      isPlaceholder = true;
      const placeholderId = "SHA-XXXXXX";
      data = {
        orderId: placeholderId,
        customerName: email.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
        customerEmail: email,
        city: "Madrid",
        amount: "89.95",
        items: [
          "1x BLAZER AJUSTADA ASIMÉTRICA CON HOMBRERAS — Beige — Talla M",
          "1x PANTALÓN CULOTTE TELA — Negro — Talla S",
        ],
        createdAt: new Date().toISOString(),
        trackingUrl: `${TRACKING_BASE}/seguimiento?orderId=${placeholderId}`,
      };
    }

    const builder = DAY_BUILDERS.find((b) => b.day === day) ?? DAY_BUILDERS[0];
    const { subject, html } = builder.fn({
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      orderId: data.orderId ?? "SHA-XXXXXX",
      trackingUrl: data.trackingUrl,
      amount: data.amount,
      items: data.items,
      city: data.city,
      createdAt: data.createdAt,
    });

    res.json({
      isPlaceholder,
      ok: true,
      subject,
      html,
      customerName: data.customerName,
      items: data.items,
      orderId: data.orderId,
      days: DAY_BUILDERS.map((b) => ({ day: b.day, label: b.label })),
    });
  } catch (err: any) {
    console.error("[preview]", err.message);
    res.status(500).json({ error: err.message });
  }
});

/* POST /api/emails/send-to-customer
   Admin endpoint: supply a customer email → system finds their order
   (local store first, then full 3-stage Stripe fallback) and sends all 5 emails. */
router.post("/emails/send-to-customer", async (req, res) => {
  try {
    const { email } = req.body as { email?: string };
    if (!email) { res.status(400).json({ error: "Missing email" }); return; }

    /* Use the same resolveOrderData used by preview — 3-stage Stripe lookup */
    const data = await resolveOrderData(email);

    if (!data) {
      res.status(404).json({
        error: "No completed payment found for this email. Check the address and try again.",
      });
      return;
    }

    /* Ensure the order exists in the local store so sendEmailSequence works */
    let order = data.orderId ? getOrderByEmail(email) : null;
    if (!order) {
      order = createOrder({
        paymentIntentId: "",
        customerEmail: data.customerEmail,
        customerName: data.customerName,
        address: "",
        city: data.city,
        postalCode: "",
        province: "",
        country: "ES",
        amount: parseFloat(data.amount),
        items: data.items,
      });
    }

    /* Send email sequence */
    sendEmailSequence(order).catch(console.error);

    res.json({
      ok: true,
      orderId: order.orderId,
      customerName: order.customerName,
      items: order.items,
      message: "Email sequence dispatched",
    });
  } catch (err: any) {
    console.error("[send-to-customer]", err.message);
    res.status(500).json({ error: err.message });
  }
});

export default router;
